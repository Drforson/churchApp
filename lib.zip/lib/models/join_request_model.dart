import 'package:cloud_firestore/cloud_firestore.dart';

class JoinRequestModel {
  final String id;
  final String memberId;
  final String ministryId;
  final String status;
  final Timestamp timestamp;

  JoinRequestModel({
    required this.id,
    required this.memberId,
    required this.ministryId,
    required this.status,
    required this.timestamp,
  });

  factory JoinRequestModel.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return JoinRequestModel(
      id: doc.id,
      memberId: data['memberId'] ?? '',
      ministryId: data['ministryId'] ?? '',
      status: data['status'] ?? 'pending',
      timestamp: data['timestamp'] ?? Timestamp.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'memberId': memberId,
      'ministryId': ministryId,
      'status': status,
      'timestamp': timestamp,
    };
  }
}
