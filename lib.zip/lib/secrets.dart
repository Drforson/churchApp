// lib/secrets.dart (gitignore this file!)
const kGooglePlacesApiKey = String.fromEnvironment('kaaxfDsdhsvGvmN4YCyq5wDdHcc=');
