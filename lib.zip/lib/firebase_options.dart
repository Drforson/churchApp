// File: firebase_options.dart

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
    /*  case TargetPlatform.iOS:
        return ios;
*/
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: "",

  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: "AIzaSyCqTIhXmQ1XZ4LER52eaiFxW_qdGf7_Z7k",
    appId: "1:97136137754:android:1458222f1ee58a22cde3a3",
    messagingSenderId: "97136137754",
    projectId: "resmanageapp",
    storageBucket: "resmanageapp.appspot.com",
  );

  /*static const FirebaseOptions ios = FirebaseOptions(
    apiKey: "IOS_API_KEY",
    appId: "1:123456789012:ios:abcd1234efgh5678ijkl",
    messagingSenderId: "123456789012",
    projectId: "upper24-777cc",
    storageBucket: "upper24-777cc.appspot.com",
    iosClientId: "123456789012-abcd1234efgh5678ijkl.apps.googleusercontent.com",
    iosBundleId: "com.example.upper24",
  ):*/
}
