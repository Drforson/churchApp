import 'package:flutter/material.dart';

class AppThemes {
  static final ThemeData baseAdmin = ThemeData.light();
  static final ThemeData baseMember = ThemeData.light();

  /// Admin Theme – Clean, modern with warm amber tones and soft greys
  static ThemeData adminTheme = baseAdmin.copyWith(
    colorScheme: baseAdmin.colorScheme.copyWith(
      primary: const Color(0xFFDAA520), // warm goldenrod
      secondary: const Color(0xFF6D4C41), // earthy brown
    ),
    scaffoldBackgroundColor: const Color(0xFFF5F5F5),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFFDAA520),
      foregroundColor: Colors.white,
      elevation: 2,
      centerTitle: true,
    ),
    textTheme: baseAdmin.textTheme.copyWith(
      titleLarge: const TextStyle(
        fontWeight: FontWeight.w700,
        fontSize: 22,
        color: Color(0xFF3E2723),
      ),
      bodyLarge: const TextStyle(
        fontSize: 16,
        color: Color(0xFF4E342E),
      ),
    ),
    cardColor: Colors.white,
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.white,
        backgroundColor: const Color(0xFFDAA520),
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
      ),
    ),
    cardTheme: CardTheme(
      elevation: 5,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      color: Colors.white,
      shadowColor: Colors.black12,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.grey),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.grey),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.teal),
      ),
      labelStyle: const TextStyle(color: Colors.black87),
    ),
  );

  /// Member Theme – Friendly, elegant with soft purple and blush tones
  static ThemeData memberTheme = baseMember.copyWith(
    colorScheme: baseMember.colorScheme.copyWith(
      primary: const Color(0xFF9575CD), // soft purple
      secondary: const Color(0xFFFFB74D), // warm peach
    ),
    scaffoldBackgroundColor: const Color(0xFFFFFAF3),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF7E57C2),
      foregroundColor: Colors.white,
      elevation: 1,
      centerTitle: true,
    ),
    textTheme: baseMember.textTheme.copyWith(
      titleLarge: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 20,
        color: Color(0xFF4527A0),
      ),
      bodyLarge: const TextStyle(
        fontSize: 15,
        color: Color(0xFF5E35B1),
      ),
    ),
    cardColor: Colors.white,
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.white,
        backgroundColor: const Color(0xFF9575CD),
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
      ),
    ),
    cardTheme: CardTheme(
      elevation: 5,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      color: Colors.white,
      shadowColor: Colors.black12,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.grey),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.grey),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.teal),
      ),
      labelStyle: const TextStyle(color: Colors.black87),
    ),
  );
}
