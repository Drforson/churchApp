import 'package:church_management_app/widgets/rolebadge.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class HomeDashboardPage extends StatefulWidget {
  const HomeDashboardPage({super.key});

  @override
  State<HomeDashboardPage> createState() => _HomeDashboardPageState();
}

class _HomeDashboardPageState extends State<HomeDashboardPage> {
  final PageController _noticeController = PageController();
  int _currentNoticeIndex = 0;

  @override
  void initState() {
    super.initState();
    _autoScrollNotices();
  }

  void _autoScrollNotices() {
    Future.delayed(const Duration(seconds: 10), () {
      if (_noticeController.hasClients) {
        _currentNoticeIndex++;
        _noticeController.animateToPage(
          _currentNoticeIndex,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
      _autoScrollNotices();
    });
  }

  double _calculateProfileCompletion(Map<String, dynamic> userData) {
    int filledFields = 0;
    const totalFields = 5; // Adjust based on your model

    if (userData['fullName'] != null) filledFields++;
    if (userData['email'] != null) filledFields++;
    if (userData['phoneNumber'] != null) filledFields++;
    if (userData['gender'] != null) filledFields++;
    if (userData['dateOfBirth'] != null) filledFields++;

    return (filledFields / totalFields);
  }

  Widget _buildWelcomeCard(String name, String role, double profileProgress) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 12),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Colors.indigo, Colors.deepPurpleAccent]),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Welcome back,', style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 16)),
          const SizedBox(height: 6),
          Row(
            children: [
              CircleAvatar(
                backgroundColor: Colors.white,
                radius: 26,
                child: Text(name.isNotEmpty ? name[0] : '?', style: const TextStyle(fontSize: 24)),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  RoleBadge(role: role), // 🛡️ Role badge here
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: profileProgress,
            backgroundColor: Colors.white24,
            color: Colors.lightGreenAccent,
            minHeight: 8,
          ),
          const SizedBox(height: 8),
          Text(
            "Profile ${ (profileProgress * 100).toInt() }% completed",
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickLinkButton(BuildContext context, IconData icon, String label, String route) {
    return Column(
      children: [
        GestureDetector(
          onTap: () => Navigator.pushNamed(context, route),
          child: CircleAvatar(
            radius: 26,
            backgroundColor: Colors.deepPurple,
            child: Icon(icon, color: Colors.white, size: 26),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }

  Widget _buildEventCard(Map<String, dynamic> data) {
    final title = data['title'] ?? 'Untitled';
    final date = (data['startDate'] as Timestamp).toDate();
    final formatted = DateFormat.yMMMMd().add_jm().format(date);

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: const Icon(Icons.event, color: Colors.teal),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(formatted),
      ),
    );
  }

  Widget _buildBirthdayCard(Map<String, dynamic> data) {
    final fullName = "${data['firstName']} ${data['lastName']}";
    final dob = (data['dateOfBirth'] as Timestamp).toDate();

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: const Icon(Icons.cake, color: Colors.pink),
        title: Text(fullName, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("Birthday: ${DateFormat.MMMd().format(dob)}"),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance
              .collection('users')
              .doc(FirebaseAuth.instance.currentUser!.uid)
              .get(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

            final userData = snapshot.data!.data() as Map<String, dynamic>;
            final role = userData['role'] ?? 'member';
            final name = userData['fullName'] ?? 'Member';
            final profileProgress = _calculateProfileCompletion(userData);

            return RefreshIndicator(
              onRefresh: () async {
                setState(() {});
              },
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      icon: const Icon(Icons.logout, color: Colors.deepPurple),
                      onPressed: () async {
                        await FirebaseAuth.instance.signOut();
                        if (mounted) Navigator.pushReplacementNamed(context, '/login');
                      },
                    ),
                  ),
                  _buildWelcomeCard(name, role, profileProgress),
                  const SizedBox(height: 20),
                  const Text("📅 Upcoming Events", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('events')
                        .where('startDate', isGreaterThan: Timestamp.now())
                        .orderBy('startDate')
                        .limit(5)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) return const CircularProgressIndicator();
                      final events = snapshot.data!.docs;
                      if (events.isEmpty) return const Text("No upcoming events.");
                      return Column(
                        children: events.map((doc) => _buildEventCard(doc.data() as Map<String, dynamic>)).toList(),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  const Text("🎂 Birthdays This Week", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance.collection('members').snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) return const CircularProgressIndicator();
                      final now = DateTime.now();
                      final weekDates = List.generate(7, (i) => DateTime(now.year, now.month, now.day + i));
                      final birthdays = snapshot.data!.docs.where((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        if (data['dateOfBirth'] == null) return false;
                        final dob = (data['dateOfBirth'] as Timestamp).toDate();
                        return weekDates.any((d) => d.month == dob.month && d.day == dob.day);
                      }).toList();

                      if (birthdays.isEmpty) return const Text("No birthdays this week.");
                      return Column(
                        children: birthdays.map((doc) => _buildBirthdayCard(doc.data() as Map<String, dynamic>)).toList(),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  const Text("⚡ Quick Links", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 120,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        _buildQuickLinkButton(context, Icons.group, "Ministries", "/view-ministry"),
                        const SizedBox(width: 16),
                        _buildQuickLinkButton(context, Icons.card_giftcard, "Giving", "/giving"),
                        const SizedBox(width: 16),
                        _buildQuickLinkButton(context, Icons.event, "Events", "/events"),
                        const SizedBox(width: 16),
                        _buildQuickLinkButton(context, Icons.person, "Profile", "/profile"),
                        const SizedBox(width: 16),
                        if (role == 'admin' || role == 'leader' || role=="member")
                          _buildQuickLinkButton(context, Icons.admin_panel_settings, "Admin Tools", "/testadmin"),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
