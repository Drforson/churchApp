import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class EventsPage extends StatelessWidget {
  Future<void> _rsvpToEvent(String eventId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      final docRef = FirebaseFirestore.instance.collection('event_rsvps').doc('$eventId-$uid');
      await docRef.set({
        'eventId': eventId,
        'userId': uid,
        'timestamp': Timestamp.now(),
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upcoming Events')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('events')
            .orderBy('date')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final events = snapshot.data?.docs ?? [];

          if (events.isEmpty) {
            return const Center(child: Text('No upcoming events.'));
          }

          return ListView.builder(
            itemCount: events.length,
            itemBuilder: (context, index) {
              final event = events[index];
              final title = event['title'];
              final date = event['date'].toDate();
              final description = event['description'];

              return Card(
                margin: const EdgeInsets.all(12),
                elevation: 4,
                child: ListTile(
                  title: Text(title),
                  subtitle: Text('${date.toLocal()}\n$description'),
                  trailing: ElevatedButton(
                    child: const Text('RSVP'),
                    onPressed: () => _rsvpToEvent(event.id),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
