import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/ministry_model.dart';
// ⬇️ updated import: singular file/class name
import 'ministries_details_page.dart';

class MinistresPage extends StatefulWidget {
  const MinistresPage({super.key});

  @override
  State<MinistresPage> createState() => _MinistresPageState();
}

class _MinistresPageState extends State<MinistresPage> {
  String? currentUserId;
  List<String> roles = [];
  bool _loading = true;
  Set<String> pendingJoinRequests = {};
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      currentUserId = user.uid;
      _fetchUserData();
    }
  }

  Future<void> _fetchUserData() async {
    if (currentUserId == null) return;

    final userDoc = await FirebaseFirestore.instance.collection('users').doc(currentUserId).get();
    if (!userDoc.exists) return;

    final userData = userDoc.data()!;
    final List<String> fetchedRoles = List<String>.from(userData['roles'] ?? []);

    final joinRequestsSnapshot = await FirebaseFirestore.instance
        .collection('join_requests')
        .where('memberId', isEqualTo: currentUserId)
        .where('status', isEqualTo: 'pending')
        .get();

    final pendingMinistryIds = joinRequestsSnapshot.docs.map((doc) {
      final data = doc.data();
      return data['ministryId'] as String;
    }).toSet();

    setState(() {
      roles = fetchedRoles;
      pendingJoinRequests = pendingMinistryIds;
      _loading = false;
    });
  }

  bool get isAdmin => roles.contains('admin');

  bool _isLeaderOfMinistry(MinistryModel ministry) {
    return ministry.leaderIds.contains(currentUserId);
  }

  Future<int> _getMemberCount(String ministryName) async {
    final membersSnapshot = await FirebaseFirestore.instance
        .collection('members')
        .where('ministries', arrayContains: ministryName)
        .get();
    return membersSnapshot.size;
  }

  Future<void> _sendJoinRequest(String ministryName) async {
    if (currentUserId == null) return;

    try {
      final joinRef = FirebaseFirestore.instance.collection('join_requests').doc();
      await joinRef.set({
        'id': joinRef.id,
        'ministryId': ministryName,
        'memberId': currentUserId,
        'status': 'pending',
        'requestedAt': Timestamp.now(),
      });

      setState(() {
        pendingJoinRequests.add(ministryName);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Join request sent successfully!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send join request: $e')),
      );
    }
  }

  Future<void> _cancelJoinRequest(String ministryName) async {
    if (currentUserId == null) return;

    final query = await FirebaseFirestore.instance
        .collection('join_requests')
        .where('memberId', isEqualTo: currentUserId)
        .where('ministryId', isEqualTo: ministryName)
        .where('status', isEqualTo: 'pending')
        .limit(1)
        .get();

    if (query.docs.isNotEmpty) {
      await FirebaseFirestore.instance.collection('join_requests').doc(query.docs.first.id).delete();
      setState(() {
        pendingJoinRequests.remove(ministryName);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Join request cancelled')),
      );
    }
  }

  Widget _buildMinistryCard(MinistryModel ministry, bool isMember) {
    final isLeader = _isLeaderOfMinistry(ministry);
    final hasPendingRequest = pendingJoinRequests.contains(ministry.name);
    final bool hasAccess = isMember || isAdmin;

    return FutureBuilder<int>(
      future: _getMemberCount(ministry.name),
      builder: (context, snapshot) {
        final memberCount = snapshot.data ?? 0;

        return Opacity(
          opacity: hasAccess ? 1.0 : 0.6,
          child: Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            elevation: 5,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              title: Row(
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        Flexible(
                          child: Text(
                            ministry.name,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: hasAccess ? Colors.black : Colors.grey[700],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (!hasAccess)
                          const Icon(Icons.lock_outline, size: 20, color: Colors.grey)
                        else if (isAdmin && !isMember)
                          const Icon(Icons.lock_open, size: 20, color: Colors.green),
                      ],
                    ),
                  ),
                  if (isLeader)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade100,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'Leader',
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  '${ministry.description}\nMembers: $memberCount',
                  style: TextStyle(
                    height: 1.5,
                    color: hasAccess ? Colors.black54 : Colors.grey,
                  ),
                ),
              ),
              trailing: isAdmin
                  ? null
                  : isMember
                  ? const Text('Member', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))
                  : hasPendingRequest
                  ? TextButton(
                onPressed: () => _cancelJoinRequest(ministry.name),
                child: const Text('Cancel', style: TextStyle(color: Colors.red)),
              )
                  : ElevatedButton(
                onPressed: () => _sendJoinRequest(ministry.name),
                style: ElevatedButton.styleFrom(
                  backgroundColor: hasAccess ? null : Colors.grey,
                ),
                child: const Text('Join'),
              ),
              isThreeLine: true,
              onTap: () {
                if (hasAccess) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      // ⬇️ updated to the new class and constructor
                      builder: (context) => MinistryDetailsPage(
                        ministryId: ministry.id,       // ensure your model exposes id
                        ministryName: ministry.name,   // used for display & membership queries
                      ),
                    ),
                  );
                } else {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('Access Denied'),
                      content: const Text('You must be a member or admin to view details.'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(),
                          child: const Text('OK'),
                        ),
                      ],
                    ),
                  );
                }
              },
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ministries'),
        actions: [
          if (isAdmin)
            IconButton(
              icon: const Icon(Icons.add),
              onPressed: () {}, // Add your create ministry logic here
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search ministries...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.trim().toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: FutureBuilder<DocumentSnapshot>(
              future: FirebaseFirestore.instance.collection('users').doc(currentUserId).get(),
              builder: (context, userSnapshot) {
                if (!userSnapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final userData = userSnapshot.data!.data() as Map<String, dynamic>?;
                final memberId = userData?['memberId'];

                if (memberId == null) {
                  return const Center(child: Text('No member record found.'));
                }

                return StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance.collection('members').doc(memberId).snapshots(),
                  builder: (context, memberSnapshot) {
                    if (!memberSnapshot.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    final memberData = memberSnapshot.data!.data() as Map<String, dynamic>?;
                    final List<String> userMinistries = List<String>.from(memberData?['ministries'] ?? []);

                    return StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance.collection('ministries').snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const Center(child: CircularProgressIndicator());
                        }

                        final allMinistries = snapshot.data!.docs.map((doc) {
                          final data = doc.data() as Map<String, dynamic>;
                          return MinistryModel(
                            id: doc.id,
                            name: data['name'] ?? 'Unnamed Ministry',
                            description: data['description'] ?? '',
                            leaderIds: List<String>.from(data['leaderIds'] ?? []),
                            createdBy: data['createdBy'] ?? '',
                          );
                        }).where((ministry) => ministry.name.toLowerCase().contains(_searchQuery)).toList();

                        final myMinistries =
                        allMinistries.where((ministry) => userMinistries.contains(ministry.name)).toList();
                        final otherMinistries =
                        allMinistries.where((ministry) => !userMinistries.contains(ministry.name)).toList();

                        return ListView(
                          children: [
                            if (myMinistries.isNotEmpty) ...[
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      'My Ministries',
                                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                    ),
                                    CircleAvatar(
                                      backgroundColor: Colors.blue,
                                      child: Text('${myMinistries.length}',
                                          style: const TextStyle(color: Colors.white)),
                                    ),
                                  ],
                                ),
                              ),
                              ...myMinistries.map((ministry) => _buildMinistryCard(ministry, true)),
                            ],
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Other Ministries',
                                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                  ),
                                  CircleAvatar(
                                    backgroundColor: Colors.green,
                                    child: Text('${otherMinistries.length}',
                                        style: const TextStyle(color: Colors.white)),
                                  ),
                                ],
                              ),
                            ),
                            ...otherMinistries.map((ministry) => _buildMinistryCard(ministry, false)),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
