import 'package:church_management_app/services/profilecompletionservice.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _profileService = ProfileCompletionService();
  double _completion = 0.0;
  String? _memberId;

  @override
  void initState() {
    super.initState();
    _loadProfileCompletion();
  }

  Future<void> _loadProfileCompletion() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    // Fetch linked memberId
    final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    final memberId = userDoc.data()?['memberId'];
    if (memberId == null) return;

    final completion = await _profileService.calculateCompletion(memberId);

    setState(() {
      _memberId = memberId;
      _completion = completion;
    });
  }

  @override
  Widget build(BuildContext context) {
    final percent = (_completion * 100).toStringAsFixed(0);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Text(
              'Profile Completion: $percent%',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: _completion,
              minHeight: 10,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(Colors.indigo),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: Center(
                child: _completion < 1.0
                    ? const Text('Complete your profile to unlock all features!', style: TextStyle(fontSize: 16))
                    : const Text('🎉 Your profile is complete!', style: TextStyle(fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
