import 'package:church_management_app/pages/add_event_page.dart';
import 'package:church_management_app/pages/attendance_checkin_page.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'admin_upload_page.dart';
import 'view_members_page.dart';
import 'post_announcements_page.dart';

class AdminDashboardPage extends StatelessWidget {
  const AdminDashboardPage({super.key});

  void _logout(BuildContext context) async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => _logout(context),
            tooltip: 'Logout',
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFE0EAFC), Color(0xFFCFDEF3)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _NoticeBoard(),
                  const SizedBox(height: 20),
                  Card(
                    color: Colors.white.withOpacity(0.95),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 6,
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Welcome, Admin!', style: Theme.of(context).textTheme.titleLarge),
                          const SizedBox(height: 8),
                          Text('Manage your church content and community tools from here.',
                              style: Theme.of(context).textTheme.bodyLarge),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  _buildActionButton(
                    context,
                    icon: Icons.upload,
                    label: 'Upload Sermons & Events',
                    onTap: () => Navigator.pushNamed(context, '/admin-upload'),
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.how_to_reg,
                    label: 'Register Member/Visitor',
                    onTap: () => Navigator.pushNamed(context, '/register-member'),
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.group,
                    label: 'View Members',
                    onTap: () => Navigator.pushNamed(context, '/view-members'),
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.group_work,
                    label: 'Manage Ministries',
                    onTap: () => Navigator.pushNamed(context, '/view-ministry'),

                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.campaign,
                    label: 'Post Announcements',
                    onTap: () => Navigator.pushNamed(context, '/post-announcements'),
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.event,
                    label: 'Events',
                    onTap: () => Navigator.pushNamed(context, '/events'),
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.event,
                    label: 'upload database',
                    onTap: () => Navigator.pushNamed(context, '/uploadExcel'),
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.check_circle_outline,
                    label: 'Attendance Check-In',
                    onTap: () => Navigator.pushNamed(context, '/attendance'),
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.person_off,
                    label: 'Sunday Follow-Up',
                    onTap: () => Navigator.pushNamed(context, '/follow-up'),
                  ),

                  _buildActionButton(
                    context,
                    icon: Icons.admin_panel_settings,
                    label: 'become Admin',
                    onTap: () => Navigator.pushNamed(context, '/testadmin'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(BuildContext context,
      {required IconData icon, required String label, required VoidCallback onTap})
  {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon),
        label: Text(label, style: Theme.of(context).textTheme.bodyLarge),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFFAFAFA),
          foregroundColor: Colors.black87,
          elevation: 3,
          padding: const EdgeInsets.symmetric(vertical: 16),
          minimumSize: const Size.fromHeight(55),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}

class _NoticeBoard extends StatefulWidget {
  const _NoticeBoard({Key? key}) : super(key: key);

  @override
  State<_NoticeBoard> createState() => _NoticeBoardState();
}

class _NoticeBoardState extends State<_NoticeBoard> {
  final PageController _controller = PageController(viewportFraction: 0.9);
  int _currentPage = 0;
  List<DocumentSnapshot> _combined = [];

  @override
  void initState() {
    super.initState();
    _fetchContent();

    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 10));
      if (!mounted || _combined.isEmpty) return false;
      _currentPage = (_currentPage + 1) % _combined.length;
      _controller.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
      return true;
    });
  }

  void _fetchContent() async {
    final now = DateTime.now();
    try {
      final eventSnap = await FirebaseFirestore.instance
          .collection('events')
          .where('startDate', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
          .orderBy('startDate')
          .get();

      final annSnap = await FirebaseFirestore.instance
          .collection('announcements')
          .orderBy('createdAt', descending: true)
          .get();

      setState(() {
        _combined = [...eventSnap.docs, ...annSnap.docs];
      });
    } catch (e) {
      print('Error loading noticeboard data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_combined.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          height: 100,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.4),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white70),
          ),
          child: Text(
            'No upcoming events or announcements.',
            style: Theme.of(context).textTheme.bodyLarge,
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white70),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: SizedBox(
        height: 160,
        child: PageView.builder(
          controller: _controller,
          itemCount: _combined.length,
          itemBuilder: (context, index) {
            final doc = _combined[index];
            final rawData = doc.data();
            if (rawData == null) return const SizedBox.shrink();

            final data = rawData as Map<String, dynamic>;
            final isEvent = data.containsKey('startDate');
            final dateStr = isEvent && data['startDate'] is Timestamp
                ? DateFormat('EEE, MMM d, yyyy').format((data['startDate'] as Timestamp).toDate())
                : null;

            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: Icon(
                  isEvent ? Icons.event : Icons.campaign,
                  color: isEvent ? Colors.deepPurple : Colors.orange,
                ),
                title: Text(data['title'] ?? 'No Title', style: Theme.of(context).textTheme.bodyLarge),
                subtitle: Text(
                  isEvent ? dateStr ?? 'Unknown Date' : (data['body'] ?? 'No content'),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
