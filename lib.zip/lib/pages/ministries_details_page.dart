// lib/pages/ministry_details_page.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/firestore_paths.dart';
import 'ministry_feed_page.dart';

class MinistryDetailsPage extends StatefulWidget {
  final String ministryId;
  final String ministryName;

  const MinistryDetailsPage({
    super.key,
    required this.ministryId,
    required this.ministryName,
  });

  @override
  State<MinistryDetailsPage> createState() => _MinistryDetailsPageState();
}

class _MinistryDetailsPageState extends State<MinistryDetailsPage>
    with TickerProviderStateMixin {
  late final TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this); // Overview / Members / Feed
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.ministryName),
        bottom: TabBar(
          controller: _tab,
          tabs: const [
            Tab(text: 'Overview'),
            Tab(text: 'Members'),
            Tab(text: 'Feed'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _OverviewTab(ministryId: widget.ministryId),
          _MembersTab(
            ministryName: widget.ministryName, // <- fixed
            ministryId: widget.ministryId,
          ),
          MinistryFeedPage(
            ministryId: widget.ministryId,
            ministryName: widget.ministryName,
          ),
        ],
      ),
    );
  }
}

// ------------------------------ Overview Tab ------------------------------
class _OverviewTab extends StatelessWidget {
  final String ministryId;
  const _OverviewTab({required this.ministryId});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: FirebaseFirestore.instance.doc(FP.ministry(ministryId)).get(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data?.data() ?? {};
          final description = (data['description'] ?? '') as String;
          final createdAt = data['createdAt'];
          final created = (createdAt is Timestamp) ? createdAt.toDate() : null;

          return ListView(
            children: [
              ListTile(
                leading: const Icon(Icons.badge_outlined),
                title: const Text('Ministry ID'),
                subtitle: Text(ministryId),
              ),
              if (description.isNotEmpty) ...[
                const SizedBox(height: 8),
                const Text('About', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(description),
              ],
              if (created != null) ...[
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Icon(Icons.event_note, size: 18),
                    const SizedBox(width: 6),
                    Text('Created: ${DateFormat.yMMMd().add_jm().format(created.toLocal())}'),
                  ],
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

// ------------------------------ Members Tab ------------------------------
class _MembersTab extends StatefulWidget {
  final String ministryName;
  final String? ministryId;

  const _MembersTab({
    super.key,
    required this.ministryName,
    this.ministryId,
  });

  @override
  State<_MembersTab> createState() => _MembersTabState();
}

class _MembersTabState extends State<_MembersTab> {
  late Future<List<Map<String, dynamic>>> membersFuture;
  late Future<List<Map<String, dynamic>>> joinRequestsFuture;

  String? currentUserId;
  Map<String, dynamic>? currentUserData;
  bool _isProcessing = false;
  final Set<String> _processingRequests = {};
  List<Map<String, dynamic>> allMembers = [];
  List<Map<String, dynamic>> filteredMembers = [];
  final TextEditingController _searchController = TextEditingController();
  String _filterType = 'All'; // All, Leaders, Members

  @override
  void initState() {
    super.initState();
    currentUserId = FirebaseAuth.instance.currentUser?.uid;
    _fetchCurrentUser();
    membersFuture = _fetchMembers();
    joinRequestsFuture = _fetchJoinRequests();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchCurrentUser() async {
    if (currentUserId == null) return;
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUserId)
          .get();
      if (userDoc.exists) {
        final data = userDoc.data() ?? {};
        final roles = (data['roles'] is List)
            ? List<String>.from(data['roles'])
            : <String>[];
        final leadershipMinistries = (data['leadershipMinistries'] is List)
            ? List<String>.from(data['leadershipMinistries'])
            : <String>[];
        setState(() {
          currentUserData = {
            'roles': roles,
            'leadershipMinistries': leadershipMinistries,
          };
        });
      }
    } catch (e) {
      debugPrint('Error fetching user: $e');
    }
  }

  bool isAdmin() {
    if (currentUserData == null) return false;
    final roles = List<String>.from(currentUserData!['roles']);
    return roles.contains('admin');
  }

  bool isAdminOrLeaderOfThisMinistry() {
    if (currentUserData == null) return false;
    final roles = List<String>.from(currentUserData!['roles']);
    final leadershipMinistries =
    List<String>.from(currentUserData!['leadershipMinistries']);
    return roles.contains('admin') ||
        (roles.contains('leader') &&
            leadershipMinistries.contains(widget.ministryName));
  }

  Future<void> _promoteToLeader(String memberId) async {
    setState(() => _isProcessing = true);
    try {
      final userLeadershipMinistries =
      List<String>.from(currentUserData!['leadershipMinistries']);
      final memberDoc = await FirebaseFirestore.instance
          .collection('members')
          .doc(memberId)
          .get();
      final memberData = memberDoc.data() as Map<String, dynamic>?;
      final memberMinistries =
      List<String>.from(memberData?['ministries'] ?? []);

      final isLeaderAllowed = memberMinistries.contains(widget.ministryName) &&
          userLeadershipMinistries.contains(widget.ministryName);

      if (!isLeaderAllowed && !isAdmin()) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('❌ You are not allowed to promote this member.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      final memberRef =
      FirebaseFirestore.instance.collection('members').doc(memberId);
      final userQuery = await FirebaseFirestore.instance
          .collection('users')
          .where('memberId', isEqualTo: memberId)
          .limit(1)
          .get();

      await memberRef.update({
        'leadershipMinistries': FieldValue.arrayUnion([widget.ministryName]),
      });

      if (userQuery.docs.isNotEmpty) {
        final userDocRef = userQuery.docs.first.reference;
        final userData = await userDocRef.get();
        final currentRoles =
        List<String>.from(userData.data()?['roles'] ?? []);
        final currentLeadership =
        List<String>.from(userData.data()?['leadershipMinistries'] ?? []);

        final updatedRoles = {...currentRoles, 'leader'}.toList();
        final updatedLeadership = {
          ...currentLeadership,
          widget.ministryName
        }.toList();

        await userDocRef.update({
          'roles': updatedRoles,
          'leadershipMinistries': updatedLeadership,
        });
      }
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('✅ Promoted to Leader')));
      setState(() {
        membersFuture = _fetchMembers();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error promoting member: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Future<void> _demoteFromLeader(String memberId) async {
    setState(() => _isProcessing = true);
    try {
      final userLeadershipMinistries =
      List<String>.from(currentUserData!['leadershipMinistries']);
      final memberDoc = await FirebaseFirestore.instance
          .collection('members')
          .doc(memberId)
          .get();
      final memberData = memberDoc.data() as Map<String, dynamic>?;
      final memberLeadershipMinistries =
      List<String>.from(memberData?['leadershipMinistries'] ?? []);

      final isLeaderAllowed =
          memberLeadershipMinistries.contains(widget.ministryName) &&
              userLeadershipMinistries.contains(widget.ministryName);

      if (!isLeaderAllowed && !isAdmin()) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('❌ You are not allowed to demote this member.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      final memberRef =
      FirebaseFirestore.instance.collection('members').doc(memberId);
      final userQuery = await FirebaseFirestore.instance
          .collection('users')
          .where('memberId', isEqualTo: memberId)
          .limit(1)
          .get();

      await memberRef.update({
        'leadershipMinistries': FieldValue.arrayRemove([widget.ministryName]),
      });

      if (userQuery.docs.isNotEmpty) {
        final userDocRef = userQuery.docs.first.reference;
        final userData = await userDocRef.get();
        final currentLeadership =
        List<String>.from(userData.data()?['leadershipMinistries'] ?? []);
        final updatedLeadership =
        currentLeadership..remove(widget.ministryName);

        final updateData = {
          'leadershipMinistries': updatedLeadership,
        };

        if (updatedLeadership.isEmpty) {
          final currentRoles =
          List<String>.from(userData.data()?['roles'] ?? []);
          final updatedRoles = currentRoles..remove('leader');
          updateData['roles'] = updatedRoles;
        }

        await userDocRef.update(updateData);
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Demoted from Leader')),
      );
      setState(() {
        membersFuture = _fetchMembers();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error demoting member: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Future<void> _removeFromMinistry(String memberId) async {
    setState(() => _isProcessing = true);
    try {
      final userLeadershipMinistries =
      List<String>.from(currentUserData!['leadershipMinistries']);
      final memberDoc = await FirebaseFirestore.instance
          .collection('members')
          .doc(memberId)
          .get();
      final memberData = memberDoc.data() as Map<String, dynamic>?;
      final memberMinistries =
      List<String>.from(memberData?['ministries'] ?? []);

      final isLeaderAllowed =
          memberMinistries.contains(widget.ministryName) &&
              userLeadershipMinistries.contains(widget.ministryName);

      if (!isLeaderAllowed && !isAdmin()) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('❌ You are not allowed to remove this member.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      await FirebaseFirestore.instance
          .collection('members')
          .doc(memberId)
          .update({
        'ministries': FieldValue.arrayRemove([widget.ministryName]),
        'leadershipMinistries': FieldValue.arrayRemove([widget.ministryName]),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('✅ Removed from ${widget.ministryName}')),
      );
      setState(() {
        membersFuture = _fetchMembers();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error removing member: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Future<List<Map<String, dynamic>>> _fetchMembers() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('members')
        .where('ministries', arrayContains: widget.ministryName)
        .get();

    final members = snapshot.docs.map((doc) {
      final data = doc.data();
      return {
        'id': doc.id,
        'name':
        ('${data['firstName'] ?? ''} ${data['lastName'] ?? ''}').trim(),
        'email': data['email'] ?? '',
        'ministries': List<String>.from(data['ministries'] ?? []),
        'isLeader':
        (data['leadershipMinistries'] ?? []).contains(widget.ministryName),
      };
    }).toList();

    allMembers = members;
    filteredMembers = members;
    return members;
  }

  Future<Map<String, dynamic>?> fetchMemberById(String userId) async {
    try {
      // 1) users/{userId} -> memberId
      final userDoc =
      await FirebaseFirestore.instance.collection('users').doc(userId).get();
      if (!userDoc.exists) return null;
      final memberId = userDoc.data()?['memberId'];
      if (memberId == null) return null;

      // 2) members/{memberId}
      final memberDoc = await FirebaseFirestore.instance
          .collection('members')
          .doc(memberId)
          .get();
      if (!memberDoc.exists) return null;
      return memberDoc.data();
    } catch (e) {
      debugPrint('❌ Error fetching member by user ID: $e');
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> _fetchJoinRequests() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('join_requests')
          .where('ministryId', isEqualTo: widget.ministryName)
          .where('status', isEqualTo: 'pending')
          .get();

      return Future.wait(snapshot.docs.map((doc) async {
        final data = doc.data();
        final memberId = data['memberId']; // this is actually userId in your note

        if (memberId != null) {
          final memberData = await fetchMemberById(memberId);
          if (memberData != null) {
            final firstName = memberData['firstName'] ?? '';
            final lastName = memberData['lastName'] ?? '';
            final fullName = ('$firstName $lastName').trim();

            return {
              'id': doc.id,
              'memberId': memberId,
              'requestedAt':
              (data['requestedAt'] as Timestamp?)?.toDate() ??
                  DateTime.now(),
              'fullName': fullName.isEmpty ? 'Unnamed Member' : fullName,
            };
          }
        }

        // Fallback
        return {
          'id': doc.id,
          'memberId': memberId ?? '',
          'requestedAt':
          (data['requestedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
          'fullName': 'Unknown Member',
        };
      }).toList());
    } catch (e) {
      debugPrint('❌ Error fetching join requests: $e');
      return [];
    }
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      filteredMembers = allMembers.where((member) {
        final name = (member['name'] as String).toLowerCase();
        final email = (member['email'] as String).toLowerCase();
        final matchesSearch = name.contains(query) || email.contains(query);
        if (_filterType == 'Leaders') {
          return matchesSearch && member['isLeader'] == true;
        } else if (_filterType == 'Members') {
          return matchesSearch && member['isLeader'] != true;
        }
        return matchesSearch;
      }).toList();
    });
    // No need to call setState again in listeners since we already are in setState.
  }

  Future<bool?> _showConfirmationDialog(
      BuildContext context,
      String title,
      String content,
      ) async {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  Future<void> _approveJoinRequest(String requestId, String userId) async {
    setState(() {
      _processingRequests.add(requestId);
    });

    try {
      // verify request exists
      final joinReq =
      await FirebaseFirestore.instance.collection('join_requests').doc(requestId).get();
      if (!joinReq.exists) {
        throw Exception('Join request not found for ID: $requestId');
      }

      // get real memberId via users/{userId}
      final userSnap =
      await FirebaseFirestore.instance.collection('users').doc(userId).get();
      if (!userSnap.exists) {
        throw Exception('User not found for ID: $userId');
      }
      final realMemberId = userSnap.data()?['memberId'];
      if (realMemberId == null) {
        throw Exception('User does not have a linked memberId');
      }

      // confirm member exists
      final memberSnap = await FirebaseFirestore.instance
          .collection('members')
          .doc(realMemberId)
          .get();
      if (!memberSnap.exists) {
        throw Exception('Member not found for ID: $realMemberId');
      }

      // approve + add membership
      await FirebaseFirestore.instance
          .collection('join_requests')
          .doc(requestId)
          .update({'status': 'approved'});

      await FirebaseFirestore.instance.collection('members').doc(realMemberId).update({
        'ministries': FieldValue.arrayUnion([widget.ministryName]),
      });

      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('✅ Request approved')));

      setState(() {
        joinRequestsFuture = _fetchJoinRequests();
        membersFuture = _fetchMembers();
      });
    } catch (e) {
      debugPrint('❌ Error approving join request: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error approving request: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() {
        _processingRequests.remove(requestId);
      });
    }
  }

  Future<void> _rejectJoinRequest(String requestId) async {
    setState(() {
      _processingRequests.add(requestId);
    });
    try {
      await FirebaseFirestore.instance
          .collection('join_requests')
          .doc(requestId)
          .update({'status': 'rejected'});
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('✅ Request rejected')));
      setState(() {
        joinRequestsFuture = _fetchJoinRequests();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error rejecting request: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() {
        _processingRequests.remove(requestId);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return currentUserData == null
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
      onRefresh: () async {
        setState(() {
          membersFuture = _fetchMembers();
          joinRequestsFuture = _fetchJoinRequests();
        });
      },
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (isAdminOrLeaderOfThisMinistry()) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ChoiceChip(
                  label: const Text('All'),
                  selected: _filterType == 'All',
                  onSelected: (selected) {
                    if (selected) {
                      setState(() {
                        _filterType = 'All';
                        _onSearchChanged();
                      });
                    }
                  },
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('Leaders'),
                  selected: _filterType == 'Leaders',
                  onSelected: (selected) {
                    if (selected) {
                      setState(() {
                        _filterType = 'Leaders';
                        _onSearchChanged();
                      });
                    }
                  },
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('Members'),
                  selected: _filterType == 'Members',
                  onSelected: (selected) {
                    if (selected) {
                      setState(() {
                        _filterType = 'Members';
                        _onSearchChanged();
                      });
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                hintText: 'Search members...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Join Requests',
                style:
                TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: joinRequestsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }
                final requests = snapshot.data ?? [];
                if (requests.isEmpty) {
                  return const Text('No pending join requests.');
                }
                return Column(
                  children: requests
                      .map(
                        (request) => Card(
                      child: ListTile(
                        title: Text(request['fullName']),
                        subtitle: Text(
                          'Requested at: ${DateFormat.yMMMd().format(request['requestedAt'])}',
                        ),
                        trailing: _processingRequests
                            .contains(request['id'])
                            ? const SizedBox(
                          height: 24,
                          width: 24,
                          child: CircularProgressIndicator(
                              strokeWidth: 2),
                        )
                            : Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(
                                Icons.check_circle,
                                color: Colors.green,
                              ),
                              onPressed: () => _approveJoinRequest(
                                  request['id'],
                                  request['memberId']),
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.cancel,
                                color: Colors.red,
                              ),
                              onPressed: () =>
                                  _rejectJoinRequest(
                                      request['id']),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                      .toList(),
                );
              },
            ),
          ],
          const SizedBox(height: 30),
          const Text('Members',
              style:
              TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: membersFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              }
              final members = filteredMembers;
              if (members.isEmpty) {
                return const Text('No members found.');
              }
              return Column(
                children: members
                    .map(
                      (member) => Card(
                    child: ListTile(
                      leading: member['isLeader'] == true
                          ? const Icon(Icons.star,
                          color: Colors.amber)
                          : const Icon(Icons.person_outline),
                      title: Row(
                        children: [
                          Text(member['name']),
                          if (member['isLeader'] == true) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.amber.shade100,
                                borderRadius:
                                BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'Leader',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      subtitle: Text(member['email']),
                      trailing: isAdminOrLeaderOfThisMinistry()
                          ? PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'Promote') {
                            final confirmed =
                            await _showConfirmationDialog(
                              context,
                              'Promote to Leader',
                              'Are you sure you want to promote ${member['name']} to Leader?',
                            );
                            if (confirmed == true) {
                              await _promoteToLeader(
                                  member['id']);
                            }
                          } else if (value == 'Demote') {
                            final confirmed =
                            await _showConfirmationDialog(
                              context,
                              'Demote from Leader',
                              'Are you sure you want to demote ${member['name']} from Leader?',
                            );
                            if (confirmed == true) {
                              await _demoteFromLeader(
                                  member['id']);
                            }
                          } else if (value == 'Remove') {
                            final confirmed =
                            await _showConfirmationDialog(
                              context,
                              'Remove from Ministry',
                              'Are you sure you want to remove ${member['name']} from ${widget.ministryName}?',
                            );
                            if (confirmed == true) {
                              await _removeFromMinistry(
                                  member['id']);
                            }
                          }
                        },
                        itemBuilder: (context) => [
                          if (member['isLeader'] != true)
                            const PopupMenuItem(
                              value: 'Promote',
                              child:
                              Text('Promote to Leader'),
                            ),
                          if (member['isLeader'] == true)
                            const PopupMenuItem(
                              value: 'Demote',
                              child:
                              Text('Demote from Leader'),
                            ),
                          const PopupMenuItem(
                            value: 'Remove',
                            child: Text('Remove from Ministry'),
                          ),
                        ],
                      )
                          : null,
                    ),
                  ),
                )
                    .toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}
