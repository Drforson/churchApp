// Full updated file with all enhancements
// (Due to character limits, I will paste this in chunks. Here's Part 1 of 2)

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class FollowUpPage extends StatefulWidget {
  const FollowUpPage({super.key});

  @override
  State<FollowUpPage> createState() => _FollowUpPageState();
}

class _FollowUpPageState extends State<FollowUpPage> {
  List<Map<String, dynamic>> _absentMembers = [];
  List<Map<String, dynamic>> _absentVisitors = [];

  List<Map<String, dynamic>> _filteredMembers = [];
  List<Map<String, dynamic>> _filteredVisitors = [];

  int _newMembersCount = 0;
  int _birthdayCount = 0;
  double _memberAttendanceRate = 0;
  double _visitorAttendanceRate = 0;

  bool _loading = true;
  String _searchQuery = '';
  String _statusMessage = 'Checking attendance...';

  String? _selectedDateKey;
  List<String> _availableDateKeys = [];

  @override
  void initState() {
    super.initState();
    _loadAvailableDates();
  }

  Future<void> _loadAvailableDates() async {
    try {
      final snap = await FirebaseFirestore.instance.collection('attendance').get();
      final keys = snap.docs.map((doc) => doc.id).toList()..sort((a, b) => b.compareTo(a));
      setState(() {
        _availableDateKeys = keys;
        _selectedDateKey = keys.isNotEmpty ? keys.first : null;
      });
      if (_selectedDateKey != null) await _loadAbsenteesAndStats();
    } catch (e) {
      setState(() => _statusMessage = 'Error fetching dates: $e');
    }
  }

  Future<void> _loadAbsenteesAndStats() async {
    if (_selectedDateKey == null) return;
    setState(() => _loading = true);

    try {
      final membersSnap = await FirebaseFirestore.instance.collection('members').get();
      final members = membersSnap.docs.map((doc) => {'id': doc.id, ...doc.data() as Map<String, dynamic>}).toList();

      final confirmedMembers = members.where((m) => m['isVisitor'] != true).toList();
      final visitors = members.where((m) => m['isVisitor'] == true).toList();

      final attendanceSnap = await FirebaseFirestore.instance
          .collection('attendance')
          .doc(_selectedDateKey)
          .collection('records')
          .get();

      final presentIds = attendanceSnap.docs.where((r) => r['present'] == true).map((r) => r['memberId'] as String).toSet();

      final absentees = confirmedMembers.where((m) => !presentIds.contains(m['id'])).toList();
      final absenteeVisitors = visitors.where((v) => !presentIds.contains(v['id'])).toList();

      final dateParts = _selectedDateKey!.split('-').map(int.parse).toList();
      final selectedDate = DateTime(dateParts[0], dateParts[1], dateParts[2]);
      final lastWeekMonday = selectedDate.subtract(const Duration(days: 6));

      final newMembers = confirmedMembers.where((m) {
        final ts = m['createdAt'] as Timestamp?;
        if (ts == null) return false;
        final created = ts.toDate();
        return created.year == selectedDate.year &&
            created.month == selectedDate.month &&
            created.day == selectedDate.day;
      }).toList();

      final birthdays = confirmedMembers.where((m) {
        final ts = m['dateOfBirth'] as Timestamp?;
        if (ts == null) return false;
        final bday = ts.toDate();
        return bday.isAfter(lastWeekMonday.subtract(const Duration(days: 1))) &&
            bday.isBefore(selectedDate.add(const Duration(days: 1)));
      }).toList();

      final presentMembers = confirmedMembers.where((m) => presentIds.contains(m['id'])).length;
      final presentVisitors = visitors.where((v) => presentIds.contains(v['id'])).length;

      _memberAttendanceRate = confirmedMembers.isEmpty ? 0 : (presentMembers / confirmedMembers.length * 100);
      _visitorAttendanceRate = visitors.isEmpty ? 0 : (presentVisitors / visitors.length * 100);

      setState(() {
        _absentMembers = _filteredMembers = absentees;
        _absentVisitors = _filteredVisitors = absenteeVisitors;
        _newMembersCount = newMembers.length;
        _birthdayCount = birthdays.length;
        _statusMessage = (absentees.isEmpty && absenteeVisitors.isEmpty)
            ? 'Everyone attended! 🎉'
            : '${absentees.length} members and ${absenteeVisitors.length} visitors missed this date.';
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _statusMessage = 'Error loading data: $e';
        _loading = false;
      });
    }
  }

  void _onSearch(String query) {
    setState(() {
      _searchQuery = query;
      _filteredMembers = _absentMembers
          .where((m) => ('${m['firstName']} ${m['lastName']}').toLowerCase().contains(query.toLowerCase()))
          .toList();
      _filteredVisitors = _absentVisitors
          .where((v) => ('${v['firstName']} ${v['lastName']}').toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }
  Widget _buildDateDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedDateKey,
      isExpanded: true,
      decoration: InputDecoration(
        labelText: 'Select Attendance Date',
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
      items: _availableDateKeys.map((key) {
        String label;
        try {
          final parsed = DateTime.parse(key);
          label = DateFormat('EEE, MMM d, yyyy').format(parsed);
        } catch (e) {
          label = key;
        }
        return DropdownMenuItem<String>(value: key, child: Text(label));
      }).toList(),
      onChanged: (newKey) {
        if (newKey != null) {
          setState(() => _selectedDateKey = newKey);
          _loadAbsenteesAndStats();
        }
      },
    );
  }

  Widget _buildStatCard({required IconData icon, required String label, required String value, Color? color}) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color ?? Colors.teal, child: Icon(icon, color: Colors.white)),
        title: Text(label),
        subtitle: Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildSearchField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 6),
      child: TextField(
        onChanged: _onSearch,
        decoration: InputDecoration(
          prefixIcon: const Icon(Icons.search),
          hintText: 'Search absent members or visitors...',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  Widget _buildPersonCard(Map<String, dynamic> person, bool isVisitor) {
    return GestureDetector(
      onTap: () => _openContactCard(person),
      child: Card(
        elevation: 2,
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: isVisitor ? Colors.orange[100] : Colors.red[100],
            child: Icon(Icons.person_off, color: isVisitor ? Colors.orange : Colors.red),
          ),
          title: Text('${person['firstName']} ${person['lastName']}'),
          subtitle: Text(isVisitor ? 'Visitor' : 'Member'),
          trailing: const Icon(Icons.arrow_forward_ios),
        ),
      ),
    );
  }

  void _openContactCard(Map<String, dynamic> person) {
    final name = '${person['firstName'] ?? ''} ${person['lastName'] ?? ''}'.trim();
    final phone = person['phone'] ?? person['phoneNumber'] ?? '';
    final emergency = person['emergencyContactNumber'] ?? '';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _ContactCardDetail(name: name, phone: phone, emergency: emergency),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Follow-Up Summary')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        child: ListView(
          key: ValueKey(_selectedDateKey),
          padding: const EdgeInsets.symmetric(vertical: 12),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _buildDateDropdown(),
            ),
            _buildSearchField(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Column(
                children: [
                  _buildStatCard(
                    icon: Icons.group_off,
                    label: 'Absent Members',
                    value: '${_filteredMembers.length}',
                    color: Colors.red,
                  ),
                  _buildStatCard(
                    icon: Icons.person_off,
                    label: 'Absent Visitors',
                    value: '${_filteredVisitors.length}',
                    color: Colors.orange,
                  ),
                  _buildStatCard(
                    icon: Icons.person_add,
                    label: 'New Members',
                    value: '$_newMembersCount this week',
                    color: Colors.blue,
                  ),
                  _buildStatCard(
                    icon: Icons.cake,
                    label: 'Birthdays',
                    value: '$_birthdayCount this week',
                    color: Colors.purple,
                  ),
                  _buildStatCard(
                    icon: Icons.insert_chart,
                    label: 'Member Attendance Rate',
                    value: '${_memberAttendanceRate.toStringAsFixed(1)}%',
                    color: Colors.green,
                  ),
                  _buildStatCard(
                    icon: Icons.pie_chart,
                    label: 'Visitor Attendance Rate',
                    value: '${_visitorAttendanceRate.toStringAsFixed(1)}%',
                    color: Colors.teal,
                  ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Divider(),
            ),
            ..._filteredMembers.map((m) => _buildPersonCard(m, false)),
            ..._filteredVisitors.map((v) => _buildPersonCard(v, true)),
          ],
        ),
      ),
    );
  }
}

class _ContactCardDetail extends StatefulWidget {
  final String name;
  final String phone;
  final String emergency;

  const _ContactCardDetail({
    required this.name,
    required this.phone,
    required this.emergency,
  });

  @override
  State<_ContactCardDetail> createState() => _ContactCardDetailState();
}

class _ContactCardDetailState extends State<_ContactCardDetail> {
  final TextEditingController _smsController = TextEditingController();
  String _message = '';

  void _sendSMS(String number, String message) async {
    final uri = Uri.parse('sms:$number?body=${Uri.encodeComponent(message)}');
    if (await launchUrl(uri)) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('📩 SMS sent to $number')),
      );
    }
  }

  void _callNumber(String number) {
    final uri = Uri.parse('tel:$number');
    launchUrl(uri);
  }

  void _openWhatsApp(String number, String message) async {
    final uri = Uri.parse('https://wa.me/$number?text=${Uri.encodeComponent(message)}');
    if (await launchUrl(uri)) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('💬 WhatsApp message sent to $number')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _smsController.addListener(() => setState(() => _message = _smsController.text));
  }

  @override
  void dispose() {
    _smsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Text(
                widget.name,
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
            const SizedBox(height: 12),
            if (widget.phone.isNotEmpty)
              ListTile(
                leading: const Icon(Icons.phone, color: Colors.green),
                title: Text(widget.phone, style: const TextStyle(color: Colors.blue)),
                onTap: () => _callNumber(widget.phone),
              ),
            if (widget.emergency.isNotEmpty)
              ListTile(
                leading: const Icon(Icons.local_hospital, color: Colors.red),
                title: Text(widget.emergency, style: const TextStyle(color: Colors.red)),
                onTap: () => _callNumber(widget.emergency),
              ),
            const SizedBox(height: 16),
            Text('📩 Send a Message:', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            TextField(
              controller: _smsController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Write your message here...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  icon: const Icon(Icons.sms),
                  label: const Text("Send SMS"),
                  onPressed: widget.phone.isNotEmpty && _message.trim().isNotEmpty
                      ? () => _sendSMS(widget.phone, _message)
                      : null,
                ),
                ElevatedButton.icon(
                  icon: const FaIcon(FontAwesomeIcons.whatsapp),
                  label: const Text("WhatsApp"),
                  onPressed: widget.phone.isNotEmpty && _message.trim().isNotEmpty
                      ? () => _openWhatsApp(widget.phone, _message)
                      : null,
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
