import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AttendanceCheckInPage extends StatefulWidget {
  const AttendanceCheckInPage({super.key});

  @override
  State<AttendanceCheckInPage> createState() => _AttendanceCheckInPageState();
}

class _AttendanceCheckInPageState extends State<AttendanceCheckInPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Map<String, bool> attendanceStatus = {};
  List<QueryDocumentSnapshot> _members = [];
  List<QueryDocumentSnapshot> _filteredMembers = [];
  bool _loading = true;
  bool _submitting = false;
  String _searchQuery = "";

  @override
  void initState() {
    super.initState();
    _loadMembers();
  }

  Future<void> _loadMembers() async {
    final snapshot = await _firestore.collection('members').get();
    setState(() {
      _members = snapshot.docs;
      _filteredMembers = _members;
      for (var doc in _members) {
        attendanceStatus[doc.id] = false;
      }
      _loading = false;
    });
  }

  void _filterMembers(String query) {
    setState(() {
      _searchQuery = query.toLowerCase();
      _filteredMembers = _members.where((doc) {
        final data = doc.data() as Map<String, dynamic>? ?? {};
        final firstName = data['firstName'] ?? '';
        final lastName = data['lastName'] ?? '';
        final fullName = '$firstName $lastName'.toLowerCase();
        return fullName.contains(_searchQuery);
      }).toList();
    });
  }

  Future<void> _submitAttendance() async {
    setState(() => _submitting = true);
    final now = DateTime.now();
    final dateKey = "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";

    final dateDocRef = _firestore.collection('attendance').doc(dateKey);
    final batch = _firestore.batch();

    batch.set(dateDocRef, {
      'createdAt': Timestamp.now(),
    });

    attendanceStatus.forEach((memberId, isPresent) {
      final docRef = dateDocRef.collection('records').doc(memberId);
      batch.set(docRef, {
        'memberId': memberId,
        'present': isPresent,
        'timestamp': now,
      });
    });

    await batch.commit();
    setState(() => _submitting = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Attendance successfully recorded.", style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.white)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final int totalMembers = _filteredMembers.length;
    final int absentMembers = _filteredMembers.where((doc) => !(attendanceStatus[doc.id] ?? false)).length;

    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Check-In', style: Theme.of(context).textTheme.bodyLarge),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFE0EAFC), Color(0xFFCFDEF3)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: "Search members...",
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onChanged: _filterMembers,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Total: $totalMembers | Absent: $absentMembers',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              Expanded(
                child: _filteredMembers.isEmpty
                    ? Center(
                  child: Text("No matching members found.", style: Theme.of(context).textTheme.bodyLarge),
                )
                    : ListView.builder(
                  itemCount: _filteredMembers.length,
                  itemBuilder: (context, index) {
                    final doc = _filteredMembers[index];
                    final data = doc.data() as Map<String, dynamic>? ?? {};
                    final firstName = data['firstName'] ?? '';
                    final lastName = data['lastName'] ?? '';
                    final fullName = '$firstName $lastName'.trim();
                    final id = doc.id;
                    final isPresent = attendanceStatus[id] ?? false;

                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      elevation: 3,
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        leading: CircleAvatar(
                          backgroundColor: isPresent ? Colors.green : Colors.grey,
                          child: Text(
                            firstName.isNotEmpty ? firstName[0].toUpperCase() : '?',
                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.white),
                          ),
                        ),
                        title: Text(
                          fullName,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        subtitle: data['gender'] != null ? Text('Gender: ${data['gender']}') : null,
                        trailing: Switch(
                          value: isPresent,
                          onChanged: (val) {
                            setState(() {
                              attendanceStatus[id] = val;
                            });
                          },
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _submitting ? null : _submitAttendance,
        label: Text(
          _submitting ? "Submitting..." : "Submit Attendance",
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        icon: const Icon(Icons.check_circle_outline),
        backgroundColor: Colors.teal,
      ),
    );
  }
}
